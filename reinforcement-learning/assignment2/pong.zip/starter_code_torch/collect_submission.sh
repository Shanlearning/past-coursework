rm -f assignment2.zip 
zip -r assignment2.zip "q2_schedule.py" "q3_linear_torch.py" "q4_nature_torch.py"
