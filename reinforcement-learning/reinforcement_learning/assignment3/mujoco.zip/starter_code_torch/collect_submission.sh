rm -f assignment3.zip
cd code
zip assignment3.zip network_utils.py policy.py policy_gradient.py baseline_network.py
mv assignment3.zip ../
cd ../
